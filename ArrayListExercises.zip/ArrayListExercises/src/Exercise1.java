import java.util.ArrayList;

public class Exercise1 {
	public static void main(String[] args) {
		ArrayList<String> colors = new ArrayList<>();
		
		colors.add("red");
		colors.add("orange");
		colors.add("yellow");
		colors.add("green");
		
		
		System.out.println("Colors ArrayList : " + colors);
		
		
	}
}
