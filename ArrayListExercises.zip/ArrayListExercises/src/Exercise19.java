import java.util.ArrayList;

public class Exercise19 {
	public static void main(String[] args) {
		ArrayList<String> colors = new ArrayList<>();
		
		colors.add("red");
		colors.add("orange");
		colors.add("yellow");
		colors.add("green");
	
		//trim the size of the ArrayList to its current size
		colors.trimToSize();
	
	}
}
