import java.util.ArrayList;

public class Exercise3 {
	public static void main(String[] args) {
		ArrayList<String> colors = new ArrayList<>();
		
		colors.add("red");
		colors.add("orange");
		colors.add("yellow");
		colors.add("green");
		
		//Retrieve the item at first position in the arraylist
		System.out.println("1st color : " + colors.get(0));
		
	}
}
